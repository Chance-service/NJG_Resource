return "is_r2_platform"
				
				
				
				
				
				
				
				
