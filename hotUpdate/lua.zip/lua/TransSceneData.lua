TransSceneData = { }

TransSceneData.transSpine = nil
TransSceneData.playingAniName = ""
TransSceneData.pageContainer = nil
TransSceneData.callback = nil