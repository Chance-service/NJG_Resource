--累计登陆奖励配置文件,d为天数，r为对应的奖励编号，配置在reward.txt中--
local CumulativeLoginConfig = {
        id = 27,
        DailyRewardItem = {
             [1] = {d = 1, 	r = 27006},
        },
        HELP = "HelpCumulativeLogin"
}

return CumulativeLoginConfig