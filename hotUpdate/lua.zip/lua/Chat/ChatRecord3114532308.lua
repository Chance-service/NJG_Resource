local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=32308,chatTime=1569657227,msgList={},
isOffline=true,chatUnit={playerId=32308,headIcon=0,roleItemId=5,avatarId=0,rebirthStage=0,level=80,senderIdentify=a([[]]),name=a([[金剛]])},
hasNewMsg=true}
return GetAllChatRecordFiles