local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=55,chatTime=1561305627,msgList={},
isOffline=true,chatUnit={playerId=55,headIcon=0,roleItemId=6,avatarId=0,rebirthStage=1,level=133,senderIdentify=a([[]]),name=a([[小※孟]])},
hasNewMsg=true}
return GetAllChatRecordFiles