local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=8913,chatTime=1562922542.3127,msgList={},
chatUnit={playerId=8913,headIcon=139,roleItemId=6,avatarId=0,rebirthStage=0,level=107,senderIdentify=a([[]]),name=a([[Funny]])},
hasNewMsg=false}
return GetAllChatRecordFiles