local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=20072,chatTime=1563988493.588,msgList={[1]={receiveId=20507,skinId=9999,headIcon=129,msgType=3,senderIdentify=a([[]]),message=a([[認証ありがとうございます/7/]]),jsonType=0,receiveName=a([[Nagu]]),titleId=0,msTime=1563988488,senderName=a([[Nagu]]),senderId=20072,area=a([[]])},[2]={receiveId=20507,skinId=9999,headIcon=129,msgType=3,senderIdentify=a([[]]),message=a([[よろしくお願いします/4/]]),jsonType=0,receiveName=a([[Nagu]]),titleId=0,msTime=1563988493,senderName=a([[Nagu]]),senderId=20072,area=a([[]])}},
chatUnit={playerId=20072,headIcon=129,roleItemId=4,avatarId=0,rebirthStage=0,level=106,senderIdentify=a([[]]),name=a([[Nagu]])},
hasNewMsg=false}
return GetAllChatRecordFiles