local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=112,chatTime=1722394622,msgList={},
isOffline=true,chatUnit={playerId=112,headIcon=0,roleItemId=999,avatarId=0,rebirthStage=0,level=91,senderIdentify=a([[]]),name=a([[是是]])},
hasNewMsg=true}
return GetAllChatRecordFiles