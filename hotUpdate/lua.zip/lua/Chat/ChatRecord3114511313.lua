local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=11313,chatTime=1569657227,msgList={},
isOffline=true,chatUnit={playerId=11313,headIcon=0,roleItemId=4,avatarId=0,rebirthStage=1,level=122,senderIdentify=a([[]]),name=a([[ToooMo]])},
hasNewMsg=true}
return GetAllChatRecordFiles