local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local SaveChatRecordIdList = {
getChatPlayerIdList17={},
getChatPlayerIdList12={},
getChatPlayerIdList3={},
getChatPlayerIdList4={},
getChatPlayerIdList2={},
getChatPlayerIdList73={},
getChatPlayerIdList586={},
getChatPlayerIdList7={},
getChatPlayerIdList1326={},
}
return SaveChatRecordIdList