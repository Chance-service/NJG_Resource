local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=35,chatTime=1562922535.3341,msgList={},
chatUnit={playerId=35,headIcon=0,roleItemId=5,avatarId=0,rebirthStage=0,level=93,senderIdentify=a([[]]),name=a([[98k]])},
hasNewMsg=false}
return GetAllChatRecordFiles