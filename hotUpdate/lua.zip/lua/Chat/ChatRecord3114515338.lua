local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=15338,chatTime=1569657227,msgList={},
isOffline=true,chatUnit={playerId=15338,headIcon=0,roleItemId=6,avatarId=0,rebirthStage=1,level=114,senderIdentify=a([[]]),name=a([[天々座理世]])},
hasNewMsg=true}
return GetAllChatRecordFiles