local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=544,chatTime=1565648918,msgList={},
isOffline=true,chatUnit={playerId=544,headIcon=0,roleItemId=6,avatarId=0,rebirthStage=1,level=123,senderIdentify=a([[]]),name=a([[你带饭]])},
hasNewMsg=true}
return GetAllChatRecordFiles