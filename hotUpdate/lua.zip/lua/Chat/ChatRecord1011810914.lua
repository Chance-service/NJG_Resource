local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=10914,chatTime=1562948729.9307,msgList={[1]={receiveId=10118,skinId=0,headIcon=0,msgType=3,senderIdentify=a([[]]),message=a([[今はギルドメンバーの募集ってしてますか？]]),jsonType=0,receiveName=a([[]]),titleId=0,msTime=1562948730,senderName=a([[]]),senderId=10914,area=a([[]])}},
chatUnit={playerId=10914,headIcon=0,roleItemId=4,avatarId=0,rebirthStage=0,level=82,senderIdentify=a([[]]),name=a([[]])},
hasNewMsg=true}
return GetAllChatRecordFiles