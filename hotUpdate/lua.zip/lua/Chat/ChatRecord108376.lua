local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=376,chatTime=1561216552.0254,msgList={},
chatUnit={playerId=376,headIcon=135,roleItemId=5,avatarId=0,rebirthStage=0,level=149,senderIdentify=a([[]]),name=a([[大宽宽]])},
hasNewMsg=false}
return GetAllChatRecordFiles