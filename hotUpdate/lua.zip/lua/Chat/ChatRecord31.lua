local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=1,chatTime=1582007209.2167,msgList={[1]={receiveId=3,skinId=0,headIcon=0,msgType=3,senderIdentify=a([[]]),message=a([[987改名為改名987]]),jsonType=0,receiveName=a([[改名987]]),titleId=0,msTime=1582007209,senderName=a([[改名987]]),senderId=1,area=a([[]])}},
chatUnit={playerId=1,headIcon=0,roleItemId=6,avatarId=0,rebirthStage=0,level=89,senderIdentify=a([[]]),name=a([[改名987]])},
hasNewMsg=true}
return GetAllChatRecordFiles