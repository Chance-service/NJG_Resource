local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=17878,chatTime=1563260902,msgList={},
isOffline=true,chatUnit={playerId=17878,headIcon=0,roleItemId=6,avatarId=0,rebirthStage=1,level=125,senderIdentify=a([[]]),name=a([[フォルテ]])},
hasNewMsg=true}
return GetAllChatRecordFiles