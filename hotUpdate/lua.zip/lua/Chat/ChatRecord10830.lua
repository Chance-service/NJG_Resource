local function a(str) str = string.gsub(str,"%<","[") str = string.gsub(str,"%>","]") return str end 
local GetAllChatRecordFiles = {
newMsgSaveFlag=false,uniquePlayerId=30,chatTime=1561216540.9667,msgList={},
chatUnit={playerId=30,headIcon=0,roleItemId=5,avatarId=0,rebirthStage=0,level=121,senderIdentify=a([[]]),name=a([[虎拓弓1]])},
hasNewMsg=false}
return GetAllChatRecordFiles